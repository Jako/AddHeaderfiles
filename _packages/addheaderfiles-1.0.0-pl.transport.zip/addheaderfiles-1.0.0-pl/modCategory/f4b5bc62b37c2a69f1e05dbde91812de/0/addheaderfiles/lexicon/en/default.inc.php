<?php
/**
 * Default English Lexicon Entries for AddHeaderfiles
 *
 * @package addheaderfiles
 * @subpackage lexicon
 */

$_lang['addheaderfiles'] = 'AddHeaderfiles';
