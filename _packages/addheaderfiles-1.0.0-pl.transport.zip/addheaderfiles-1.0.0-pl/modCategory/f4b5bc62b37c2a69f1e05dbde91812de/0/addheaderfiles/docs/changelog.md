# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2016-10-21
### Changed
- Bugfix for detecting head area code

## [0.6.1] - 2014-03-17
### Changed
- Bugfix for detecting head area code

## [0.6.1] - 2013-10-21
### Changed
- Bugfix for detecting head area code

## [0.6.0] - 2013-10-21
### Changed
- Better external css file detection

## [0.5.0] - 2012-09-04
### Added
- Initial release for MODX Revolution
